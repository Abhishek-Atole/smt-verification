# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- **Zod Schema Validation**: Comprehensive input validation across all API POST/PATCH endpoints (31 schemas covering BOM, sessions, scans, auth, and reports)
- **PII Anonymization**: SHA256 hashing for IP addresses and user-agent strings in report exports
- **90-Day Data Purge**: Automatic retention policy for anonymized audit data via `purge_after` timestamp
- **Excel Export Streaming**: Promise-based streaming for large report exports using `createWriteStream()`
- **React State Validation**: Enhanced date range validation in report filters with functional state updates
- **Validation Documentation**: SCHEMA_CODE_REFERENCE.md and SCHEMA_VALIDATION_IMPLEMENTATION.md guides

### Security
- **PII Anonymization**: Database migration (0009_pii_anonymization.sql) replacing raw IP addresses and user-agent with SHA256 hashes
- **Input Validation**: All POST/PATCH routes now validate request bodies against Zod schemas before database operations
- **Password Strength**: Enhanced authentication schema with 8+ character minimum, uppercase/lowercase/number/special character requirements
- **GDPR/DPDP Compliance**: 90-day automatic purge of anonymized audit data for data retention compliance
- **Secrets Management**: All CI/CD secrets properly stored in GitHub Secrets (no hardcoded credentials)

### Changed
- **API Response Format**: Validation errors now return detailed fieldErrors in standard format: `{ error: "Validation failed", details: { fieldErrors: {...} } }`
- **Express Middleware**: Validation middleware applied to BOM routes (POST /bom, PATCH /bom/:bomId, POST /bom/:bomId/items, etc.)

### Fixed
- **Excel Export**: Fixed streaming implementation to properly handle large files without memory bloat
- **React Closure Bug**: Fixed stale state closure in date filter by using separate handlers and parameter passing
- **Build Errors**: Resolved Zod dependency issues in API server package.json

## [v0.0.1] - 2026-04-24

### Added
- Initial SMT Verification System release
- Multi-role access control (Admin, Engineer, QA, Operator)
- BOM management with CSV import/export
- Feeder scanning and verification (AUTO/MANUAL modes)
- Session-based verification tracking
- PDF/Excel/CSV report generation
- Audit trail with 7-endpoint API
- Traceability queries with 7-endpoint API
- Database schema with soft-delete support
- RESTful API with rate limiting and JWT authentication
- React frontend with Vite bundling
- PostgreSQL database with Drizzle ORM

---

## How to Update This Changelog

Add entries under **[Unreleased]** as you work on features:

1. **Added** - New features
2. **Changed** - Changes in existing functionality
3. **Deprecated** - Soon-to-be removed features
4. **Removed** - Now removed features
5. **Fixed** - Bug fixes
6. **Security** - Security vulnerability fixes

When preparing a release (e.g., v1.0.0), move **[Unreleased]** section to a new versioned section with today's date:

```markdown
## [1.0.0] - 2026-05-06

### Added
- Feature X
```

Then create a new empty **[Unreleased]** section at the top.
