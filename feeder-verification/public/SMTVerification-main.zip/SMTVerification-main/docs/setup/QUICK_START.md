# Quick Start Guide - 5-Minute Setup

## ⚡ 5-Minute Setup

### Prerequisites

- PostgreSQL running locally
- Node.js and pnpm installed
- Environment variables configured

### Quick Setup

```bash
# 1. Start API server
cd artifacts/api-server
pnpm install
pnpm dev

# 2. In another terminal, run migrations
cd lib/db
DATABASE_URL="postgresql://smtverify@localhost:5432/smtverify" pnpm push

# 3. Navigate back and seed data
cd ../../artifacts/api-server
# Server should be running on http://localhost:3000
```

### Company Logo

Configure the report branding values in `.env`:

```bash
COMPANY_NAME=UCAL Electronics PVT. LTD
COMPANY_LOGO_PATH=./assets/company-logo.png
```

For frontend PDF rendering, place the logo file at:

```text
artifacts/feeder-scanner/public/assets/company-logo.png
```

## Default User Accounts

Run once after database migration:

```bash
pnpm --filter @workspace/api-server run seed:users
```

Default credentials (change after first login in production):

| Username | Password | Role |
|---|---|---|
| operator1 | <set-on-first-login> | operator |
| operator2 | <set-on-first-login> | operator |
| qa1 | <set-on-first-login> | qa |
| engineer1 | <set-on-first-login> | engineer |

IMPORTANT: Change all default passwords before production deployment.
Use POST /api/auth/change-password after first login.

---

## 🎯 First Steps

### Test 1: Health Check

```bash
curl http://localhost:3000/api/health
```

### Test 2: Seed Database

```bash
curl -X POST http://localhost:3000/api/test/seed-quick
```

### Test 3: View Statistics

```bash
curl http://localhost:3000/api/test/stats | jq '.'
```

### Test 4: Try Traceability

```bash
curl http://localhost:3000/api/traceability/session/1/trace | jq '.'
```

### Test 5: Try Audit

```bash
curl http://localhost:3000/api/audit/logs/bom/1 | jq '.'
```
