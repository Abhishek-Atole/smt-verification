# Security Policy

## Supported Versions

| Version | Release Date | End of Support | Status |
|---------|-------------|-----------------|--------|
| 1.0.x   | 2026-04-01  | 2027-04-01      | ✅ Supported |
| 0.9.x   | 2026-01-15  | 2026-10-15      | 🔶 Maintenance |

## Reporting a Vulnerability

We take security seriously. If you discover a vulnerability, please report it **privately** and responsibly.

### How to Report
- **Email:** security@example.com
- **Do NOT open a public GitHub issue** for security vulnerabilities
- Include: vulnerability description, affected component, proof-of-concept (if possible)

### Response Timeline
- **Acknowledgement:** Within 48 hours
- **Status Update:** Within 7 days
- **Patch Release:** Within 30 days (critical), 90 days (other)

### What to Expect
- CVE assignment for critical vulnerabilities
- Credit in changelog (unless you prefer anonymity)
- No legal action taken against good-faith security researchers
- Private disclosure window before public patch release

## Security Architecture

### Authentication & Passwords
- User passwords hashed with **bcrypt** (cost factor ≥ 12)
- Session tokens are JWT-based with 24-hour expiration
- No persistent refresh tokens stored
- Default credentials must be changed in production (see Deployment Checklist)

### Database Security
- All queries use **parameterized queries via Drizzle ORM**
- No string interpolation for SQL operations
- Prepared statements prevent SQL injection

### File Operations
- Export endpoints validate file paths against base directory (path traversal protection)
- CSV export sanitizes headers to prevent formula injection (e.g., `=`, `+`, `@` prefixes removed)
- File downloads restricted to authenticated users

## Known Limitations

### Rate Limiting
⚠️ **Not yet implemented** — the API is not rate-limited. Deploy behind a reverse proxy (nginx/HAProxy) with rate limiting enabled.

### IP Address Retention
- Client IP addresses logged in `report_exports.ip_address`
- **Retention policy:** Must be defined based on regulatory requirements (GDPR, local data protection laws)
- Consider implementing automated log purging or pseudonymization

## Production Deployment Checklist

- [ ] **Change all default passwords** — Update operator1, operator2, qa1, engineer1 credentials
- [ ] **Set strong JWT_SECRET** — Use ≥ 64 random characters (e.g., `openssl rand -hex 32`)
- [ ] **Disable test endpoints** — Remove/disable `/api/test/seed`, `/api/test/clear`, `/api/test/stats`
- [ ] **Enable HTTPS/TLS** — Use valid certificate; terminate SSL at reverse proxy
- [ ] **Configure CORS** — Set `ALLOWED_ORIGINS` to specific production domains only
- [ ] **Enable rate limiting** — Deploy nginx/HAProxy with rate limit rules
- [ ] **Review audit logs** — Enable centralized logging; monitor for unauthorized access attempts
- [ ] **Set environment variables** — Verify `.env` does not contain test/dummy values

## Compliance & Standards

- **OWASP Top 10:** Addressed via parameterized queries, password hashing, CORS, authentication
- **GDPR:** User data should have retention and deletion policies; audit logs subject to data minimization
- **Manufacturing Compliance:** Audit trail captures all quality-related operations per industry standards

## Questions?

For security inquiries, contact: security@example.com

---

**Last Updated:** May 6, 2026  
**Next Review:** November 6, 2026
