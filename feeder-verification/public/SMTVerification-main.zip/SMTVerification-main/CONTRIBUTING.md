# Contributing to SMT Verification System

Thank you for your interest in contributing to the SMT Verification System! This document provides guidelines and instructions for contributing to the project.

## Table of Contents

- [Development Environment Setup](#development-environment-setup)
- [Branch Naming Convention](#branch-naming-convention)
- [Making Changes](#making-changes)
- [PR Checklist](#pr-checklist)
- [Code Review Process](#code-review-process)
- [Reporting Issues](#reporting-issues)

---

## Development Environment Setup

### Prerequisites

- **Node.js**: Version 20+ (specified in `.nvmrc`)
- **pnpm**: Version 8.0.0+ (monorepo package manager)
- **PostgreSQL**: Version 14+ (database)
- **Git**: For version control

### Setup Steps

1. **Clone the repository**:
   ```bash
   git clone https://github.com/Abhishek-Atole/SMTVerification.git
   cd SMTVerification
   ```

2. **Install dependencies**:
   ```bash
   pnpm install
   ```

3. **Set up environment variables**:
   ```bash
   # Create .env.local (copy from .env.example if available)
   cp .env.example .env.local
   # Edit with your PostgreSQL connection details:
   # DATABASE_URL=postgresql://user:password@localhost:5432/smt_verification
   # JWT_SECRET=your-secret-key
   # NODE_ENV=development
   ```

4. **Run database migrations**:
   ```bash
   pnpm --filter @workspace/db push
   ```

5. **Seed default users** (for testing):
   ```bash
   pnpm --filter @workspace/api-server run seed:users
   ```

6. **Start API server** (terminal 1):
   ```bash
   cd artifacts/api-server
   pnpm dev
   # Runs on localhost:3000
   ```

7. **Start frontend** (terminal 2):
   ```bash
   cd artifacts/feeder-scanner
   pnpm dev
   # Runs on localhost:5173
   ```

### Verification

Verify your setup by checking:

```bash
# Type checking
pnpm typecheck

# API server health
curl http://localhost:3000/api/health

# Frontend loads
open http://localhost:5173
```

---

## Branch Naming Convention

Use the following prefix system for branch names:

### Branch Prefixes

| Prefix | Purpose | Example |
|--------|---------|---------|
| `feat/` | New feature | `feat/add-pdf-export` |
| `fix/` | Bug fix | `fix/session-date-validation` |
| `chore/` | Maintenance, deps | `chore/update-zod-version` |
| `docs/` | Documentation | `docs/api-reference` |
| `test/` | Tests only | `test/add-integration-tests` |
| `refactor/` | Code restructuring | `refactor/extract-validation-layer` |
| `perf/` | Performance | `perf/optimize-report-generation` |

### Examples

✅ **Good**:
- `feat/session-mode-switch`
- `fix/excel-streaming-bug`
- `chore/update-dependencies`

❌ **Avoid**:
- `update-stuff`
- `fix-things`
- `new-feature-for-bob`

---

## Making Changes

### 1. Create a Feature Branch

```bash
git checkout -b feat/your-feature-name
```

### 2. Make Your Changes

- **Keep commits atomic** - One logical change per commit
- **Write descriptive commit messages**:
  ```bash
  git commit -m "feat: add session reset endpoint

  - Implements POST /api/verification/sessions/:id/reset
  - Adds ResetSessionSchema for validation
  - Clears all scans and resets status to pending"
  ```

### 3. Run TypeScript Check

```bash
pnpm typecheck
```

Expected: **0 errors**

### 4. Run Tests

```bash
# API server tests
pnpm --filter @workspace/api-server run test

# Frontend tests
pnpm --filter @workspace/feeder-scanner run test
```

Expected: **All tests pass**

### 5. Build & Verify

```bash
pnpm build
```

Expected: **No errors, bundle sizes reasonable**

---

## PR Checklist

Before submitting a pull request, ensure you've checked all items:

### Code Quality

- [ ] **TypeScript**: `pnpm typecheck` passes with 0 errors
- [ ] **No @ts-nocheck**: Never suppress type checking in production code
- [ ] **No console.log**: Remove debug logging (use `req.log` in API, React devtools for frontend)
- [ ] **Tests Pass**: `pnpm test` passes all tests
- [ ] **Build Succeeds**: `pnpm build` completes without errors

### Documentation

- [ ] **CHANGELOG.md Updated**: Added entry under `[Unreleased]` section
- [ ] **Code Comments**: Complex logic has clear explanations
- [ ] **Type Annotations**: All functions have return types (TypeScript strict mode)
- [ ] **JSDoc**: Public API functions have JSDoc blocks

### Best Practices

- [ ] **No Secrets**: No API keys, tokens, or credentials in code
- [ ] **Security**: Input validation applied to all POST/PATCH endpoints
- [ ] **Error Handling**: Proper try-catch blocks, error logging
- [ ] **Performance**: No N+1 queries, efficient algorithms
- [ ] **Accessibility**: Frontend changes considered keyboard/screen reader use

### Database Changes

- [ ] **Migration Created**: `pnpm --filter @workspace/db push` succeeds
- [ ] **Tested Locally**: Migration runs without errors
- [ ] **Rollback Plan**: Tested migration rollback procedure

### PR Description

Your PR description should include:

```markdown
## Description
Brief summary of changes

## Type of Change
- [ ] New feature
- [ ] Bug fix
- [ ] Documentation update
- [ ] Performance improvement

## Related Issues
Closes #123

## Changes Made
- Item 1
- Item 2
- Item 3

## Testing
How to test these changes

## Screenshots (if applicable)
Any UI changes should have before/after screenshots
```

---

## Code Review Process

### Reviewer Responsibilities

1. **Code Quality**: Verify code follows project standards
2. **Security**: Check for vulnerabilities, input validation, secrets
3. **Tests**: Ensure test coverage for new features
4. **Documentation**: Verify changes are documented
5. **Performance**: Review for performance regressions

### Author Responsibilities

1. **Respond to Comments**: Address all review feedback
2. **Request Re-review**: Ask reviewer to check updates
3. **Keep PR Focused**: One logical change per PR (split if too large)
4. **Resolve Conflicts**: Handle merge conflicts promptly

### Approval Process

- **At least 1 approval** required before merge
- **All conversations resolved** before merge
- **CI/CD pipeline passes** (tests, typecheck, build)
- **No conflicts** with main branch

### Merge Strategy

- Use **"Squash and merge"** for feature branches (clean history)
- Use **"Create a merge commit"** for release branches
- Delete branch after merging

---

## Reporting Issues

### Security Issues

⚠️ **DO NOT open a public issue for security vulnerabilities**

1. See [SECURITY.md](./docs/SECURITY.md) for responsible disclosure process
2. Email security concerns to the maintainers
3. Allow time for a fix before public disclosure

### Bug Reports

1. **Check existing issues**: Search for duplicates
2. **Open a new issue** using the bug template:

```markdown
## Description
Brief summary of the bug

## Steps to Reproduce
1. Step 1
2. Step 2
3. Step 3

## Expected Behavior
What should happen

## Actual Behavior
What actually happens

## Environment
- OS: [e.g., macOS 14.0]
- Node: [output of `node --version`]
- pnpm: [output of `pnpm --version`]
- Browser: [if applicable]

## Screenshots/Logs
Include relevant error messages or screenshots
```

### Feature Requests

1. **Title**: Clear, descriptive title
2. **Description**: What problem does this solve?
3. **Use Case**: Why would someone need this?
4. **Proposed Solution**: How might it work?

---

## Project Structure

Understanding the monorepo layout helps with contributions:

```
SMTVerification/
├── artifacts/
│   ├── api-server/          # Express.js backend (port 3000)
│   ├── feeder-scanner/      # React frontend (port 5173)
│   └── mockup-sandbox/      # UI development environment
├── lib/
│   ├── db/                  # PostgreSQL schema (Drizzle ORM)
│   ├── api-zod/            # Zod validation schemas
│   └── api-client-react/   # React Query client
├── docs/                    # Documentation
├── tests/                   # Integration tests
└── scripts/                 # Utility scripts
```

## Key Concepts

### API Validation

All POST/PATCH endpoints use Zod schemas:

```typescript
// Route
router.post("/api/bom", validate(CreateBomSchema), async (req, res) => {
  const { name } = req.body; // ✓ Validated & typed
  // ...
});
```

### Session Modes

- **AUTO**: Automatic component verification
- **MANUAL**: Password-protected verification (for QA/Engineer)

### Database

- **PostgreSQL** with **Drizzle ORM**
- Migrations in `lib/db/drizzle/`
- Push migrations: `pnpm --filter @workspace/db push`
- Rollback: Reset database and re-run migrations

---

## Code Style

### TypeScript

- **Strict mode enabled**: No `any` types without justification
- **Return types required**: Functions must declare return types
- **No @ts-ignore**: Use @ts-expect-error with explanation

### Naming

- **Constants**: `UPPER_SNAKE_CASE`
- **Functions**: `camelCase`
- **Classes**: `PascalCase`
- **Types**: `PascalCase`
- **Private fields**: `_leading_underscore`

### Example

```typescript
// ✅ Good
interface UserPayload {
  username: string;
  email: string;
}

const validateUser = (payload: UserPayload): boolean => {
  return payload.username.length > 0;
};

// ❌ Avoid
interface user {
  username: any;
}

const validateUser = (payload: user) => {
  return payload.username.length > 0;
};
```

---

## Resources

- **API Reference**: [API_REFERENCE.md](./docs/guides/API_REFERENCE.md)
- **Architecture**: [SCHEMA_CODE_REFERENCE.md](./SCHEMA_CODE_REFERENCE.md)
- **Security**: [SECURITY.md](./docs/SECURITY.md)
- **System Setup**: [SYSTEM_RESTART_GUIDE.md](./docs/SYSTEM_RESTART_GUIDE.md)

---

## Questions?

- Check existing [GitHub Issues](https://github.com/Abhishek-Atole/SMTVerification/issues)
- Review [Project Documentation](./docs)
- Check [API Tests](./docs/guides/API_TESTING_GUIDE.md)

---

Thank you for contributing! 🚀
